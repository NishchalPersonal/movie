
// key: 9295ebd4
// how to use: http://www.omdbapi.com/?i=${id}&apikey=${9295ebd4}
// http://www.omdbapi.com/?i=tt3896198&apikey=9295ebd4

$(document).ready(function(){

    function showGraph(){
        fetch('http://www.omdbapi.com/?i=tt3896198&apikey=9295ebd4')
        .then((response )=> response.json())
        .then(function (inputVar){
            //console.log("testing API fetch");
            getData(inputVar);

        })
    }

    fetch('http://www.omdbapi.com/?i=tt3896198&apikey=9295ebd4')
        .then((response )=> response.json())
        .then(function (inputVar){
            //console.log("testing API fetch");
            getData(inputVar);

        })

        let posterId = document.getElementById('poster');

        let tropyId = document.getElementById('rating');

        let titleId = document.getElementById('movieTitle');


        function getData(info){

            // Title
            let createTitle = document.createElement('p');
            let title = info.Title;

            createTitle.textContent = title;
            console.log(createTitle);
            titleId.value = title;

            /*let title = info.Title;
            console.log(title);
            $("#movieTitle").attr("value", title);*/
            
            // Year
            let year = info.Year;
            $("#year").attr("value", year);

            // Genre
            let genre = info.Genre;
            $("#genre").attr("value", genre);

            
            // Runtime
            let runTime = info.Runtime;
            $("#runTime").attr("value", runTime);

            
            // Director
            let director = info.Director;
            $("#director").attr("value", director);
            
            // Writer
            let writer = info.Writer;
            $("#writer").attr("value", writer);

            // for poster
            let createPoster = document.createElement('img');
            let poster = info.Poster;

            createPoster.setAttribute('src', poster);
            createPoster.setAttribute('class', 'posterStyling');

            posterId.appendChild(createPoster); // for poster 

            // trophy

            for(let count =0; count < 8; count++){
                let createTrophy = document.createElement('img');
                createTrophy.src = "images/trophy.png";
                createTrophy.setAttribute('class', 'trophyStyling');

                tropyId.appendChild(createTrophy);
            }  
        }

})