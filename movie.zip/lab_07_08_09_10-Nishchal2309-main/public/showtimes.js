let title;
let firstDate;
let secondDate;

$(document).ready(function(){

    let search = document.getElementById('search');
    let form = document.getElementById('hideForm');

    search.onclick = function(event){
        /*data: {
            val1: variable1,
            val2: variable2
            }, */
        event.preventDefault();
        let date = document.getElementById('date');

        let location = document.getElementById('location');



        let body = document.getElementById('contantTable');
        body.innerHTML = "";
        $.ajax({
            type: "GET",
            // /showtimes
            url: "http://localhost:3000/showtimes_api",
            data: {location_id: location.value,
                selected_date: date.value},
            dataType: "json",
            success: function(inputVar){
                console.log("colnsole testing");
                console.log(location.value);

                

                let length = inputVar.length;


                for(let i =0; i < length; i++){


                    firstDate = (date.value).replace('-','/');
                    secondDate = firstDate.replace('-','/');

                    let changeLocation = parseInt(location.value);// parsing the value to int (option value instead)


                    console.log(inputVar[i].location);
                    if(secondDate === inputVar[i].date && changeLocation === inputVar[i].location){

                        
                        let divMain = document.createElement('div');

                        let getTitle = document.createElement('div');

                        title = inputVar[i].title;
                        console.log(title);

                        let info1 = document.createElement('p');
                        //let a = document.createElement('a');

                        
                        info1.textContent = title;

                        info1.setAttribute('class', 'titleStyling');
                        
                        /*$(info1).click(function(){
                            titleClicked();
                        });*/
                        info1.addEventListener("click", function(){ 
                            
                            console.log("title is clicked"); 
                            
                            if(info1.textContent == "The Sound of Music"){
                                console.log(inputVar[i].id);
                                showGraph(inputVar[i].id);     
                                form.style.display = "block"; 

                            }else if(info1.textContent=="Doctor Zhivago"){
                                showGraph(inputVar[i].id);     
                                form.style.display = "block";

                            }else if(info1.textContent=="The Great Race"){
                                showGraph(inputVar[i].id);     
                                form.style.display = "block";

                            }else if(info1.textContent=="For a Few Dollars More"){
                                showGraph(inputVar[i].id);     
                                form.style.display = "block";

                            }else if(info1.textContent=="The Rounders"){
                                showGraph(inputVar[i].id);     
                                form.style.display = "block";

                            }else if(info1.textContent=="Thunderball"){
                                showGraph(inputVar[i].id);     
                                form.style.display = "block";

                            }
                        });
                        
                        getTitle.appendChild(info1);
                        getTitle.setAttribute('class', 'tableBorder');
                        //execBtn.setAttribute("onclick", function() { runCommand() });
                        //titleClicked();
 
                        divMain.setAttribute('class', 'resultStyling');
                        divMain.appendChild(getTitle);

                        

                        //let letBuy = document.createElement('div');
                        let getTime = document.createElement('div');
                        for(let j=0; j < inputVar[i].times.length; j++){
                            let buttonForm = document.createElement('form');
                            buttonForm.id = 'buyId';
                            buttonForm.setAttribute('method', 'get');
                            buttonForm.setAttribute('action', '/buyTickets');

                            // id
                            let movie_id = document.createElement("input");

                            movie_id.setAttribute("type", "hidden");

                            movie_id.setAttribute("name", "movie_id");

                            movie_id.setAttribute("value", inputVar[i].id);

                            //console.log(movie_id);

                            // title
                            let movie_title = document.createElement("input");

                            movie_title.setAttribute("type", "hidden");

                            movie_title.setAttribute("name", "movie_title");

                            movie_title.setAttribute("value", inputVar[i].title);

                            // location id
                            let location_id = document.createElement("input");

                            location_id.setAttribute("type", "hidden");

                            location_id.setAttribute("name", "location_id");

                            location_id.setAttribute("value", inputVar[i].location);

                            // location
                            let locationSet = document.createElement("input");

                            locationSet.setAttribute("type", "hidden");

                            locationSet.setAttribute("name", "locationSet");

                            //console.log(changeLocation);
                            if(changeLocation == 1){
                                locationSet.setAttribute("value", "Oshawa Cinemas");
                            }else if(changeLocation == 2){
                                locationSet.setAttribute("value", "Ajax Cinemas");
                            }

                            // date
                            let dateSet = document.createElement("input");

                            dateSet.setAttribute("type", "hidden");

                            dateSet.setAttribute("name", "dateSet");

                            dateSet.setAttribute("value", inputVar[i].date);


                            // time
                            let start_time = document.createElement("input");

                            start_time.setAttribute("type", "hidden");

                            start_time.setAttribute("name", "start_time");

                            start_time.setAttribute("value", inputVar[i].times[0]);
                            console.log(inputVar[i].times[0]);



                            let letBuy = document.createElement('button');
                            let createBuy = document.createElement('img');
                            letBuy.setAttribute('class', 'button');
                            createBuy.src = "images/buy.png";
                            letBuy.appendChild(createBuy);

                            buttonForm.appendChild(movie_id);
                            buttonForm.appendChild(movie_title);
                            buttonForm.appendChild(location_id);
                            buttonForm.appendChild(locationSet);
                            buttonForm.appendChild(dateSet);
                            buttonForm.appendChild(start_time);
                            buttonForm.appendChild(letBuy);
                            

                            let timings = inputVar[i].times[j];
                            

                            let info2 = document.createElement('p');
                            info2.textContent = timings;

                            getTime.appendChild(info2);
                            getTime.appendChild(buttonForm);
                            
                            //
                            divMain.appendChild(getTime);
                            //divMain.setAttribute('class', 'divUnderline')

                        }
                        body.setAttribute('class', 'tablePadding');
                        body.appendChild(divMain);

                    }
                    
                }

            }
        })

    }





    function showGraph(data){

        fetch('http://www.omdbapi.com/?i='+data+'&apikey=9295ebd4')
        .then((response )=> response.json())
        .then(function (inputVar){
            //console.log("testing API fetch");
            getData(inputVar);

        })
    }

        let posterId = document.getElementById('poster');

        let tropyId = document.getElementById('rating');

        let titleId = document.getElementById('movieTitle');

        let getActor = document.getElementById('actors');

        let getPlot = document.getElementById('plot');


        function getData(info){

            // title
            let getTitle = info.Title;
            $("#movieTitle").attr("value", getTitle);

            // Year
            let year = info.Year;
            $("#year").attr("value", year);

            // Genre
            let genre = info.Genre;
            $("#genre").attr("value", genre);

            
            // Runtime
            let runTime = info.Runtime;
            $("#runTime").attr("value", runTime);

            
            // Director
            let director = info.Director;
            $("#director").attr("value", director);
            
            // Writer
            let writer = info.Writer;
            $("#writer").attr("value", writer);

            // actors
          
            //let createActor = document.createElement('p');
            let actor = info.Actors;
            
            getActor.value = actor;

            // plot
          
            //let createPlot = document.createElement('p');
            let plot = info.Plot;
            //createPlot.textContent = plot;
            getPlot.value = plot;


            //console.log(createPlot.textContent); both same
            //console.log(getPlot.value);

            // for poster
            let createPoster = document.createElement('img');
            let poster = info.Poster;

            createPoster.setAttribute('src', poster);
            createPoster.setAttribute('class', 'posterStyling');

            posterId.innerHTML = "";
            posterId.appendChild(createPoster); // for poster 


            // trophy
            tropyId.innerHTML = "";

            for(let count =0; count < 8; count++){
                let createTrophy = document.createElement('img');
                createTrophy.src = "images/trophy.png";
                createTrophy.setAttribute('class', 'trophyStyling');

                tropyId.appendChild(createTrophy);
            }  
        }
    })