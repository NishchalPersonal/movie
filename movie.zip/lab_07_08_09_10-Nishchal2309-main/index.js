let express = require('express');
let Showtime = require('./showtimes_model');
//let session = require('express-session');


let app = express();

const session = require('express-session');
const { v4: uuidv4 } = require('uuid');

app.use(express.static('public'));
app.use(express.urlencoded({extended: false}));


app.use(session({
    genid: uuidv4,
    resave: false,
    saveUninitialized: false,
    // cookie: {secure: true},
    secret: '3230 examples typing fast need coffee'
}));

// configuration
app.set('views', __dirname + '/views');
app.set('view engine', 'pug');

// first page
app.get('/', function(request, response) {
    response.send('Welcome to our page!');
});

// test buy ticket pug
app.get('/buyTickets', function(request, response){
    response.render('buyTickets',{
        title: 'buy tickets',
        message: 'this is buy tickets page',
        movie_id: request.query.movie_id,
        movie_title: request.query.movie_title,
        location_id: request.query.location_id,
        location1: request.query.locationSet,
        date1: request.query.dateSet,
        time1: request.query.start_time
    });
});

app.get('/purchaseConfirmed', function(request, response){
    response.render('purchaseConfirmed', {
        title: 'purchase confirmed',
        message: 'this is purchase confirmed page'
    })
})

app.get('/showtimes_api', function(request, response){
    //console.log(request.query.location_id);
    //console.log(request.query.selected_date); 

    let firstChange;
    let secondChange; 

    var setLocation = request.query.location_id;
    var setDate = request.query.selected_date;

    firstChange = setDate.replace('-','/');
    secondChange = firstChange.replace('-','/');
    //console.log(secondChange);
    

    Showtime.find({$and: [{"location": setLocation}, {"date": secondChange}]}).then(function(showtimes){
        console.log(showtimes);
        response.json(showtimes);
    });
})



app.set('port', process.env.PORT || 3000);

app.listen(app.get('port'), function(){
    //console.log(`listeining for requests on port 3000`);
    console.log(`Listening on port ${app.get('port')}`);

});
