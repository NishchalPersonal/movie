const mongoose = require('mongoose');

//mongodb+srv://nishchal:<password>@webdev.hwajb.mongodb.net/myFirstDatabase?retryWrites=true&w=majority
mongoose.connect("mongodb+srv://nishchal:Nishi@1999@webdev.hwajb.mongodb.net/show?retryWrites=true&w=majority", {
    useNewUrlParser: true, 
    userUnifiedTopology: true
}, function(error){
    if(error){
        console.error('unable to connect', error);
    }else{
        console.log("connected to mongoDB");
    }

});

mongoose.set('useCreateIndex', true);

const Schema = mongoose.Schema;

const mySchema = new Schema({
    // define schema here
    id: String,
    title: String,
    location: Number,
    date: String,
    times: Array
},{
    collection: 'showtimes'
});


module.exports = mongoose.model('show', mySchema, 'showtimes');
